import Phaser from "phaser";

export default class StartScene extends Phaser.Scene {
  constructor() {
    super("start-scene");
  }

  init(data) {
    this.startButton = undefined;
    this.helpButton = undefined;
  }

  preload() {
    this.load.image("background", "images/bgstart.png");
    this.load.image("start-btn", "images/start.png");
    this.load.image("tutorial-btn", "images/option.png");
  }

  create() {
    this.add.image(200, 320, "background").setScale(0.9);

    this.startButton = this.add.image(100, 290, 'start-btn').setInteractive().setScale(0.5);
    this.helpButton = this.add.image(270, 335, 'tutorial-btn').setInteractive().setScale(0.97);

//Kode untuk berpindah scene. Diisi dengan key yang ditulis pada kode super di method constructor
    this.startButton.once(
        "pointerup",() => {
          this.scene.start("alien-buster-scene1");
        }, this);
    this.helpButton.once(
      "pointerup",() => {
        this.scene.start("tutorial-alien-buster-scene");
      }, this);
  }
}