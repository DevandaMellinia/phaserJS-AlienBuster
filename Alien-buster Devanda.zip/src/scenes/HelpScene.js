import Phaser from "phaser";

export default class HelpScene extends Phaser.Scene {
  constructor() {
    super("tutorial-alien-buster-scene");
  }

  init(data) {
    this.startButton = undefined;
  }

  preload() {
    this.load.image("backgroundstart", "images/tutorial.png");
    this.load.image("start-btn", "images/start.png");

  }

  create() {
    this.add.image(200, 320, "backgroundstart").setScale(0.9);

    this.startButton = this.add.image(196, 90, 'start-btn').setInteractive().setScale(0.5);

//Kode untuk berpindah scene. Diisi dengan key yang ditulis pada kode super di method constructor
    this.startButton.once(
        "pointerup",() => {
          this.scene.start("alien-buster-scene1");
        }, this);

  }
}