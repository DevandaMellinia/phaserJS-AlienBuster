import Phaser from "phaser";
import FallingObject from "../ui/FallingObject.js";
import Laser from "../ui/Laser.js";

export default class AlienBusterScene2 extends Phaser.Scene {
  constructor() {
    super("alien-buster-scene2");
  }

  init() {
    this.clouds = undefined;
    this.nav_left = false;
    this.nav_right = false;
    this.shoot = false;

    this.player = undefined;
    this.speed = 100;

    this.enemies = undefined;
    this.enemySpeed = 50;

    this.lasers = undefined;
    this.lastFired = 0;

    this.scoreLabel = undefined;
    this.score = 0;
    this.lifeLabel = undefined;
    this.life = 3;

    this.backsound = undefined;
    this.cursor = undefined;
  }

  preload() {
    this.load.image("background2", "images/bg2.jpg");
    this.load.image("cloud", "images/cloud.png");
    this.load.image("left-btn", "images/left-btn.png");
    this.load.image("right-btn", "images/right-btn.png");
    this.load.image("shoot-btn", "images/shoot-btn.png");
    this.load.image("player", "images/ship.png");
    this.load.image("enemy", "images/enemy.png");
    this.load.image("laser", "images/laser.png");

    this.load.audio("bgsound", "sfx/bgsound.mp3");
    this.load.audio("laser", "sfx/laser.mp3");
    this.load.audio("destroy", "sfx/destroy.mp3");
    this.load.audio("explosion", "sfx/explosion.mp3");
    this.load.audio("gameover", "sfx/gameover.mp3");
  }

  create() {
    const gameWidth = this.scale.width * 0.5;
    const gameHeight = this.scale.height * 0.5;
    this.add.image(gameWidth, gameHeight, "background2");

    this.player = this.createPlayer();
    this.clouds = this.physics.add.group({
      key: "cloud",
      repeat: 10,
    });
    Phaser.Actions.RandomRectangle(this.clouds.getChildren(), this.physics.world.bounds);
    this.createButton();
    this.enemies = this.physics.add.group({
      classType: FallingObject,
      maxSize: 10,
      runChildUpdate: true,
    });

    this.time.addEvent({
      delay: Phaser.Math.Between(1000, 5000),
      callback: this.spawnEnemy,
      callbackScope: this,
      loop: true,
    });

    this.lasers = this.physics.add.group({
      classType: Laser,
      maxSize: 10,
      runChildUpdate: true,
    });

    this.physics.add.overlap(this.lasers, this.enemies, this.hitEnemy, null, this);
    this.textLabel = this.add
    .text(10, 10, "LEVEL 2", {
      fontSize: "24px",
      fill: "black",
      backgroundColor: "white",
    })
    this.scoreLabel = this.add.text(10, 50, "Score: 0", {
      fontSize: "16px",
      fill: "black",
      backgroundColor: "white",
    }).setDepth(1);

    this.lifeLabel = this.add.text(300, 10, "Lives: 3", {
      fontSize: "16px",
      fill: "black",
      backgroundColor: "white",
    }).setDepth(1);

    this.physics.add.overlap(this.player, this.enemies, this.decreaseLife, null, this);

    this.backsound = this.sound.add("bgsound");
    const soundConfig = {
      loop: true,
      volume: 0.5,
    };
    this.backsound.play(soundConfig);

    this.cursor = this.input.keyboard.createCursorKeys();
  }

  hitEnemy(laser, enemy) {
    laser.die();
    enemy.die();
    this.score += 10;
    this.sound.play("destroy");
  }

  update(time) {
    this.clouds.children.iterate((child) => {
      child.setVelocityY(20);
      if (child.y > this.scale.height) {
        child.x = Phaser.Math.Between(10, 400);
        child.y = 0;
      }
    });

    this.movePlayer(this.player, time);
    this.scoreLabel.setText("Score: " + this.score);
    this.lifeLabel.setText("Lives: " + this.life);
  }

  createButton() {
    this.input.addPointer(3);

    let shoot = this.add.image(320, 550, 'shoot-btn').setInteractive().setDepth(0.5).setAlpha(0.8);
    let nav_left = this.add.image(50, 550, 'left-btn').setInteractive().setDepth(0.5).setAlpha(0.8);
    let nav_right = this.add.image(nav_left.x + nav_left.displayWidth + 20, 550, 'right-btn').setInteractive().setDepth(0.5).setAlpha(0.8);

    nav_left.on("pointerdown", () => { this.nav_left = true; }, this);
    nav_left.on("pointerout", () => { this.nav_left = false; }, this);

    nav_right.on("pointerdown", () => { this.nav_right = true; }, this);
    nav_right.on("pointerout", () => { this.nav_right = false; }, this);

    shoot.on("pointerdown", () => { this.shoot = true; }, this);
    shoot.on("pointerout", () => { this.shoot = false; }, this);
  }

  movePlayer(player, time) {
    if (this.nav_left || this.cursor.left.isDown) {
      player.setVelocityX(this.speed * -1);
      player.setFlipX(false);
    } else if (this.nav_right || this.cursor.right.isDown) {
      player.setVelocityX(this.speed);
      player.setFlipX(true);
    } else {
      player.setVelocityX(0);
    }
  
    if (this.shoot && time > this.lastFired) {
      const laser = this.lasers.get(0, 0, "laser");
      if (laser) {
        laser.fire(this.player.x, this.player.y);
        this.lastFired = time + 150;
        this.sound.play("laser");
      }
    }
  
    if (this.score >= 60) {
      this.add.text(100, 90, "You Win!!", {
        fontSize: "50px",
        fill: "blue",
        backgroundColor: "white",
      }).setDepth(1);
  
      this.sound.stopAll();
      
      this.time.delayedCall(2000, () => {
        this.scene.start("start-scene");
      });
    }
  }

  createPlayer() {
    const player = this.physics.add.sprite(200, 450, 'player');
    player.setScale(0.5);
    player.setCollideWorldBounds(true);
    return player;
  }

  spawnEnemy() {
    const config = {
      speed: 30,
      rotation: 0.1
    };
    const enemy = this.enemies.get(0, 0, 'enemy', config);
    const positionX = Phaser.Math.Between(50, 350);
    if (enemy) {
      enemy.spawn(positionX);
      enemy.setScale(0.05);
    }
  }

  decreaseLife(player, enemy) {
    enemy.die();
    this.sound.play("explosion");
    this.life--;
    if (this.life == 2) {
      player.setTint(0xff0000);
    } else if (this.life == 1) {
      player.setTint(0xff0000).setAlpha(0.2);
    } else if (this.life == 0) {
      this.sound.stopAll();
      this.sound.play("gameover");
      this.scene.start("over-scene", { score: this.score });
    }
  }
}
