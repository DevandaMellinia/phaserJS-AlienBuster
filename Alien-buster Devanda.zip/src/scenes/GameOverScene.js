import Phaser from "phaser";

export default class GameOverScene extends Phaser.Scene {
  constructor() {
    super("over-scene");
  }

  init(data) {
    this.replayButton = undefined;
    this.homeButton = undefined;
    this.score = data.score;
  }

  preload() {
    this.load.image("bg_ove", "images/bg_ove.png");
    this.load.image("gameover", "images/gameover.png");
    this.load.image("replay-button", "images/replay.png");
    this.load.image("home-button", "images/home.png");
  }

  create() {
    this.add.image(200, 320, "bg_ove");
    this.add.image(200, 170, "gameover").setScale(0.46);

    this.add.text(95, 275, "Score : " + this.score, {
      fontSize: "32px",
      // @ts-ignore
      fill: "white",
      bold: true
    });

    this.replayButton = this.add.image(200, 355, 'replay-button')
    .setInteractive().setScale(0.5);

    this.homeButton = this.add.image(200, 455, 'home-button')
    .setInteractive().setScale(0.35);

//Kode untuk berpindah scene. Diisi dengan key yang ditulis pada kode super di method constructor
    this.replayButton.once(
        "pointerup",
        () => {
          this.scene.start("corona-buster-scene");
        },
        this
      );

      this.homeButton.once(
        "pointerup",
        () => {
          this.scene.start("start-scene");
        },
        this
      );
  }

}